# ARC 3133 Blender sessions

Open [the session index](files/blender/README.md), then choose the file for this class. Extract the complete folder first and keep the point-cloud data beside its Blender file.

Prepared in Blender 5.2.1 LTS. Native node names are retained. Save a separate working copy.
